#include "Tokens.h"

VCTen::VCTen() {
	this->setValue(10);

}