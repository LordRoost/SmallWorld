////
////  Main.cpp
////  Smallworld
////
////  Created by Eric Payette REFORMED on 2018-02-15.
////  Copyright � 2018 Eric Payette REFORMED. All rights reserved.
////
//
//#include <stdio.h>
//#include "Map.h"
//
//using namespace std;
//
////int main() {
//
//int Mapdriver(){
//
//	Map m;
//
//	m.loadMap("/Users/ericpayettereformed/Documents/Smallworld/Smallworld/MapFiles/map.txt");
//
//	//m.graphIsConnected();
//
//	return 0;
//}
