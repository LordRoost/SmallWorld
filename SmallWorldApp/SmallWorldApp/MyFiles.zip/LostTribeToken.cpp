#include "Tokens.h"

LostTribeToken::LostTribeToken() {

}